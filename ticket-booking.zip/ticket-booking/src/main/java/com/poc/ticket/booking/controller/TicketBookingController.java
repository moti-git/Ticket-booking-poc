/**
 * 
 */
package com.poc.ticket.booking.controller;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.poc.ticket.booking.model.Booking;
import com.poc.ticket.booking.model.Passenger;
import com.poc.ticket.booking.repository.PassengerRepository;
import com.poc.ticket.booking.repository.TicketBookingRepository;


/**
 * @author motjha
 *
 */
@RestController
@RequestMapping("/")
public class TicketBookingController {
	
	 private static final Log logger = LogFactory.getLog(TicketBookingController.class);
	 
	 @Autowired
	 private TicketBookingRepository bookingRepository;
	 	 
	 
	 @Autowired
	 private PassengerRepository passengerRepository;
	 
	 RestTemplate restTemplate = new RestTemplate();
	 
	    /*
	     *API to check existing booking
	     * 
	     */
	  	    
		@GetMapping(path = "/passengerverification", produces = MediaType.APPLICATION_JSON_VALUE)
		@ResponseBody
		public String checkPassengerDetails(@RequestParam("passport") String passport,
				@RequestParam("suppliedDate") String suppliedDate) throws ParseException {
			
			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			Date date = formatter.parse(suppliedDate);			 
			Optional<Passenger> passenger = passengerRepository.checkPassengerDetails(passport, date);
	
			return passenger.toString();
		}

	    /*
	     *API to check existing booking
	     * 
	     */
	    
	    @PostMapping(path = "/booking", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	    @ResponseBody
	    public String passengerBooking(@Valid @RequestBody Passenger passenger) throws ParseException {
	    	Booking bookingObj = null;
	    	logger.info("TicketBooking::passengerBooking():start");
	    	
	    	final String url = "http://localhost:8585/bookingticket/passengerverification";
	    	//HttpHeaders headers = new HttpHeaders();
	    	//headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);

	    	DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			String date = formatter.format(passenger.getDoj());
			
	    	UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
	    			  .queryParam("passport", passenger.getPassport())
	                  .queryParam("suppliedDate", date);
	    	             
	    	 String checkResponse = restTemplate.getForObject(builder.buildAndExpand().toUri(), String.class);
	    	

            if(checkResponse.equals("Optional.empty")) {
            	
            	passengerRepository.save(passenger);
            	bookingObj = new Booking();
            	bookingObj.setConfirmationCode(UUID.randomUUID().getLeastSignificantBits());
            	bookingObj.setPassenger(passenger);
            	bookingObj.setConfirmed(true);
            	bookingObj.setTimestamp(new Date());
            	bookingRepository.save(bookingObj);            	
            } else {
            	return "{msg:Ticket already booked}";
            }
	        
            logger.info("TicketBooking::passengerBooking():end");
	         return bookingObj.toString();
	    }
	    
}
