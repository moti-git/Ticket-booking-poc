package com.poc.ticket.booking.repository;


import java.util.Date;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.poc.ticket.booking.model.Passenger;
/**
 * @author motjha
 *
 */

@RepositoryRestResource
public interface PassengerRepository extends CrudRepository<Passenger, Long> {
	
	/*
	 * to check passenger details are there or not
	 */
	@Query("SELECT p FROM Passenger p where p.passport = ?1 AND p.doj = ?2")
    public Optional<Passenger> checkPassengerDetails(String passport, Date localDate);
     
    
}
