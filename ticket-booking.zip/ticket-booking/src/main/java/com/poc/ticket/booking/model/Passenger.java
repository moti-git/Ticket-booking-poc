/**
 * 
 */
package com.poc.ticket.booking.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;



/**
 * @author motjha
 *
 */
@Entity
@Table
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Passenger {

    @Id
    @GeneratedValue
    private Long id;


     @Column(nullable = false)
     private String fName;
    
   
    @Column(nullable = false)
    private String lName;
    
    
    @Column(nullable = false)
    private String passport;

   
    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)    
    private Date doj;

    @OneToMany(mappedBy = "passenger")
    @JsonIgnore
    private Set<Booking> bookings;

    
    public Set<Booking> getBookings() {
		return bookings;
	}


	public void setBookings(Set<Booking> bookings) {
		this.bookings = bookings;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getfName() {
		return fName;
	}


	public void setfName(String fName) {
		this.fName = fName;
	}


	public String getlName() {
		return lName;
	}


	public void setlName(String lName) {
		this.lName = lName;
	}


	public String getPassport() {
		return passport;
	}


	public void setPassport(String passport) {
		this.passport = passport;
	}


	public Date getDoj() {
		return doj;
	}


	public void setDoj(Date doj) {
		this.doj = doj;
	}


	@Override
    public String toString() {
        return "Passenger{" +
                "id=" + id +                
                ", fName=" + fName +
                ", lName=" + lName +
                ", passport=" + passport +
                ", doj=" + doj +
                '}';
    }
}