/**
 * 
 */
package com.poc.ticket.booking.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.poc.ticket.booking.model.Booking;

/**
 * @author motjha
 *
 */
@RepositoryRestResource
public interface TicketBookingRepository extends CrudRepository<Booking, Long> {
}
